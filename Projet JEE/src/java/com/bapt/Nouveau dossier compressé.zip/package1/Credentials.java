/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bapt.package1;

/**
 *
 * @author Baptiste
 */
public class Credentials {
    public static String type = "mysql";
    public static String db = "jeedb";
    public static String address = "myappinstance.c2wtcej1vlyc.eu-west-3.rds.amazonaws.com";
    public static String port = "3306";
    public static String user = "root";
    public static String password = "12345678";
    
}
